/*var app =
{
	initialize: function()
	{
		//console.log("Hola0");
		this.bindEvents();
	},
	bindEvents: function()
	{
		document.addEventListener('deviceready', this.onDeviceReady, false);
	},
	onDeviceReady: function()
	{
		//console.log("Hola1");
		new FastClick(document.body);
	}		
}*/